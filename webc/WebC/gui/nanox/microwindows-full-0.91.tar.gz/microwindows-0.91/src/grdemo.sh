
# Nano-X applications, press <BREAK> key to exit
bin/nano-X & bin/nanowm & bin/rgndemo & bin/dashdemo & bin/tsdemo & bin/arcdemo & bin/polydemo & bin/tux
