
#
# Microwindows coding standard indentation rules
#
indent -i8 -br -ce -npcs -nsob -bap -psl
