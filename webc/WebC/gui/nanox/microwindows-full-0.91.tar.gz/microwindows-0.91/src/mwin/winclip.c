#include "device.h"

#if DYNAMICREGIONS
#include "winclip2.c"
#else
#include "winclip1.c"
#endif
