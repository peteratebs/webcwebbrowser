bin/nano-X -p & bin/demo2; sleep 10000
