/*
 * 4bpp (16 color) grayscale palette
 */
#include "device.h"

MWPALENTRY mwstdpal4[16] = {
    RGBDEF( 0, 0, 0 ),
    RGBDEF( 17, 17, 17 ),
    RGBDEF( 34, 34, 34 ),
    RGBDEF( 51, 51, 51 ),
    RGBDEF( 68, 68, 68 ),
    RGBDEF( 85, 85, 85 ),
    RGBDEF( 102, 102, 102 ),
    RGBDEF( 119, 119, 119 ),
    RGBDEF( 136, 136, 136 ),
    RGBDEF( 153, 153, 153 ),
    RGBDEF( 170, 170, 170 ),
    RGBDEF( 187, 187, 187 ),
    RGBDEF( 204, 204, 204 ),
    RGBDEF( 221, 221, 221 ),
    RGBDEF( 238, 238, 238 ),
    RGBDEF( 255, 255, 255 )
};
