
# Nano-X applications, press <BREAK> key to exit
# bin/nano-X & bin/nanowm & bin/nxview bin/mwlogo.ppm & bin/nxclock & bin/nxmag & sleep 10000
bin/nano-X & bin/nanowm & bin/nxterm & bin/nxeyes & bin/tux & sleep 10000
