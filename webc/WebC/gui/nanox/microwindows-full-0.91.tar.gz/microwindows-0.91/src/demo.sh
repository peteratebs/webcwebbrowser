
# win32 applications, press <BREAK> key to exit
bin/mdemo
#bin/mine	# minefield
#bin/malpha	# alpha blending
