
# Nano-X grabkey test, press <BREAK> key to exit
# grab the 'a' key as exclusive hotkey
bin/nano-X & bin/nanowm & bin/nxterm & bin/grabdemo 97 n & sleep 10000
